import { Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface RoleEntry {
  icon: string;
  name: string;
  permissions: string;
}

@Component({
  selector: 'app-roles-list',
  standalone: true,
  imports: [NgFor, NgIf, FormsModule],
  templateUrl: './roles-list.component.html',
  styleUrl: './roles-list.component.scss'
})
export class RolesListComponent {

  roles: RoleEntry[] = [
    {
      icon: '👑',
      name: 'Super Admin',
      permissions: 'Dashboard, Purchase Orders, Product Intake, Stock & Bin Assignment, Store Allocation, Picker, Dispatch, Tracking, Store Receiving, Reports, Masters (Users, Drivers, Pickers, Stores, Dispatch Managers, Roles), Notifications'
    },
    {
      icon: '🛡️',
      name: 'Admin',
      permissions: 'Dashboard, Purchase Orders, Product Intake, Stock & Bin Assignment, Store Allocation, Picker, Dispatch, Tracking, Store Receiving, Reports, Masters (Drivers, Pickers, Stores, Dispatch Managers, Roles), Notifications'
    },
    {
      icon: '📌',
      name: 'Dispatcher',
      permissions: 'Dashboard, Purchase Orders (View), Product Intake (View), Stock & Bin Assignment, Store Allocation, Picker (View), Dispatch, Tracking (View), Store Receiving (View), Notifications'
    },
    {
      icon: '📦',
      name: 'Picker',
      permissions: 'Dashboard, Purchase Orders (View), Product Intake (View), Stock (View), Picker (View & Update Status), Notifications'
    },
    {
      icon: '🚛',
      name: 'Driver',
      permissions: 'Tracking (Update Location), Store Receiving (Mark Received), Notifications'
    },
  ];

  showModal = false;
  editingIndex: number | null = null;

  form: RoleEntry = { icon: '', name: '', permissions: '' };

  openAdd() {
    this.form = { icon: '', name: '', permissions: '' };
    this.editingIndex = null;
    this.showModal = true;
  }

  openEdit(index: number) {
    this.form = { ...this.roles[index] };
    this.editingIndex = index;
    this.showModal = true;
  }

  save() {
    if (!this.form.name?.trim() || !this.form.permissions?.trim()) return;

    if (this.editingIndex !== null) {
      this.roles[this.editingIndex] = { ...this.form };
    } else {
      this.roles.push({ ...this.form });
    }
    this.closeModal();
  }

  closeModal() {
    this.showModal = false;
    this.editingIndex = null;
  }
}