// import { Component } from '@angular/core';
// import { DatePipe, TitleCasePipe } from '@angular/common';
// import { RouterLink } from '@angular/router';
// import { ApiService } from '../../../core/api.service';
// import { PurchaseOrder } from '../../../models';

// @Component({
//   selector: 'app-po-list',
//   standalone: true,
//   imports: [DatePipe, TitleCasePipe, RouterLink],
//   templateUrl: './po-list.component.html',
//   styleUrl: './po-list.component.scss'
// })
// export class PoListComponent {
//   purchaseOrders: PurchaseOrder[] = [];
//   uploading = false;

//   constructor(private api: ApiService) {
//     this.load();
//   }

//   load() {
//     this.api.getPurchaseOrders().subscribe(list => this.purchaseOrders = list);
//   }

//   onFileSelect(event: Event) {
//     const input = event.target as HTMLInputElement;
//     const file = input.files?.[0];
//     if (file && file.type === 'application/pdf') {
//       this.upload(file);
//     }
//     input.value = ''; // reset so same file can be re-selected
//   }

//   private generatePoNumber(): string {
//     const seq = String(Math.floor(Math.random() * 99999) + 1).padStart(5, '0');
//     return `PO-${new Date().getFullYear()}-${seq}`;
//   }

//   private upload(file: File) {
//     this.uploading = true;
//     const po: Partial<PurchaseOrder> = {
//       poNumber: this.generatePoNumber(),
//       vendorName: '',           // vendor name baad mein edit ho sakta hai
//       fileName: file.name,
//       uploadedAt: new Date().toISOString(),
//       status: 'pending',
//       invoiceCount: 0
//     };

//     this.api.addPurchaseOrder(po).subscribe({
//       next: () => {
//         this.uploading = false;
//         this.load();
//       },
//       error: () => { this.uploading = false; }
//     });
//   }
// }





// import { Component } from '@angular/core';
// import { DatePipe, TitleCasePipe, NgIf } from '@angular/common';
// import { RouterLink } from '@angular/router';
// import { ApiService } from '../../../core/api.service';
// import { PurchaseOrder } from '../../../models';

// @Component({
//   selector: 'app-po-list',
//   standalone: true,
//   imports: [DatePipe, TitleCasePipe, NgIf, RouterLink],
//   templateUrl: './po-list.component.html',
//   styleUrl: './po-list.component.scss'
// })
// export class PoListComponent {
//   purchaseOrders: PurchaseOrder[] = [];
//   uploading = false;
//   uploadSuccess = false;

//   constructor(private api: ApiService) {
//     this.load();
//   }

//   load() {
//     this.api.getPurchaseOrders().subscribe(list => this.purchaseOrders = list);
//   }

//   onFileSelect(event: Event) {
//     const input = event.target as HTMLInputElement;
//     const file = input.files?.[0];
//     if (file && file.type === 'application/pdf') {
//       this.upload(file);
//     }
//     input.value = '';
//   }

//   private generatePoNumber(): string {
//     const seq = String(Math.floor(Math.random() * 99999) + 1).padStart(5, '0');
//     return `PO-${new Date().getFullYear()}-${seq}`;
//   }

//   private upload(file: File) {
//     this.uploading = true;
//     this.uploadSuccess = false;

//     const po: Partial<PurchaseOrder> = {
//       poNumber: this.generatePoNumber(),
//       vendorName: '',
//       fileName: file.name,
//       uploadedAt: new Date().toISOString(),
//       status: 'pending',
//       invoiceCount: 0
//     };

//     this.api.addPurchaseOrder(po).subscribe({
//       next: () => {
//         this.uploading = false;
//         this.uploadSuccess = true;
//         this.load();
//         // Toast 3 sec baad hide ho jaaye
//         setTimeout(() => this.uploadSuccess = false, 3000);
//       },
//       error: () => { this.uploading = false; }
//     });
//   }
// }



// import { Component } from '@angular/core';
// import { DatePipe, TitleCasePipe, NgIf } from '@angular/common';
// import { Router } from '@angular/router';

// interface MockPO {
//   id: number;
//   poNumber: string;
//   vendorName: string;
//   fileName: string;
//   uploadedAt: string;
//   status: 'pending' | 'in_progress' | 'completed';
//   invoiceCount: number;
// }

// @Component({
//   selector: 'app-po-list',
//   standalone: true,
//   imports: [DatePipe, TitleCasePipe, NgIf],
//   templateUrl: './po-list.component.html',
//   styleUrl: './po-list.component.scss'
// })
// export class PoListComponent {
//   uploading = false;
//   uploadSuccess = false;

//   purchaseOrders: MockPO[] = [
//     {
//       id: 1,
//       poNumber: 'PO-2025-00042',
//       vendorName: 'Samsung India Pvt Ltd',
//       fileName: 'samsung_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       status: 'pending',
//       invoiceCount: 2
//     },
//     {
//       id: 2,
//       poNumber: 'PO-2025-00043',
//       vendorName: 'Apple Distribution',
//       fileName: 'apple_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       status: 'in_progress',
//       invoiceCount: 5
//     }
//   ];

//   constructor(private router: Router) {}

//   onFileSelect(event: Event) {
//     const input = event.target as HTMLInputElement;
//     const file = input.files?.[0];
//     if (file && file.type === 'application/pdf') {
//       this.uploading = true;
//       this.uploadSuccess = false;
//       setTimeout(() => {
//         this.uploading = false;
//         this.uploadSuccess = true;
//         setTimeout(() => this.uploadSuccess = false, 3000);
//       }, 1500);
//     }
//     input.value = '';
//   }

//   viewInvoices(po: MockPO) {
//     // Product Intake module pe jaao
//     this.router.navigate(['/intake/invoices']);
//   }
// }


// import { Component } from '@angular/core';
// import { DatePipe, TitleCasePipe, NgIf } from '@angular/common';
// import { Router } from '@angular/router';

// interface MockPO {
//   id: number;
//   poNumber: string;
//   vendorName: string;
//   fileName: string;
//   uploadedAt: string;
//   qty: number;
//   received: number;
//   invoiceCount: number;
//   status: 'pending' | 'in_progress' | 'completed';
// }

// @Component({
//   selector: 'app-po-list',
//   standalone: true,
//   imports: [DatePipe, TitleCasePipe, NgIf],
//   templateUrl: './po-list.component.html',
//   styleUrl: './po-list.component.scss'
// })
// export class PoListComponent {
//   uploading = false;
//   uploadSuccess = false;

//   purchaseOrders: MockPO[] = [
//     {
//       id: 1,
//       poNumber: 'PO-2025-00042',
//       vendorName: 'Samsung India Pvt Ltd',
//       fileName: 'samsung_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       qty: 120,
//       received: 80,
//       invoiceCount: 2,
//       status: 'in_progress'
//     },
//     {
//       id: 2,
//       poNumber: 'PO-2025-00043',
//       vendorName: 'Apple Distribution',
//       fileName: 'apple_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       qty: 60,
//       received: 0,
//       invoiceCount: 0,
//       status: 'pending'
//     }
//   ];

//   constructor(private router: Router) {}

//   onFileSelect(event: Event) {
//     const input = event.target as HTMLInputElement;
//     const file = input.files?.[0];
//     if (file && file.type === 'application/pdf') {
//       this.uploading = true;
//       this.uploadSuccess = false;

//       // Mock — new PO row add karo
//       const newPO: MockPO = {
//         id: this.purchaseOrders.length + 1,
//         poNumber: `PO-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 99999)).padStart(5, '0')}`,
//         vendorName: '—',
//         fileName: file.name,
//         uploadedAt: new Date().toISOString(),
//         qty: 0,
//         received: 0,
//         invoiceCount: 0,
//         status: 'pending'
//       };

//       setTimeout(() => {
//         this.purchaseOrders = [newPO, ...this.purchaseOrders];
//         this.uploading = false;
//         this.uploadSuccess = true;
//         setTimeout(() => this.uploadSuccess = false, 3000);
//       }, 1500);
//     }
//     input.value = '';
//   }

//   viewInvoices(po: MockPO) {
//     this.router.navigate(['/intake/invoices']);
//   }
// }















// import { Component } from '@angular/core';
// import { DatePipe, TitleCasePipe, NgIf } from '@angular/common';
// import { Router } from '@angular/router';

// declare var pdfjsLib: any;

// interface MockPO {
//   id: number;
//   poNumber: string;
//   vendorName: string;
//   fileName: string;
//   uploadedAt: string;
//   qty: number;
//   received: number;
//   invoiceCount: number;
//   status: 'pending' | 'in_progress' | 'completed';
// }

// @Component({
//   selector: 'app-po-list',
//   standalone: true,
//   imports: [DatePipe, TitleCasePipe, NgIf],
//   templateUrl: './po-list.component.html',
//   styleUrl: './po-list.component.scss'
// })
// export class PoListComponent {
//   uploading = false;
//   uploadSuccess = false;
//   parsing = false;

//   purchaseOrders: MockPO[] = [
//     {
//       id: 1,
//       poNumber: 'PO-2025-00042',
//       vendorName: 'Samsung India Pvt Ltd',
//       fileName: 'samsung_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       qty: 120,
//       received: 80,
//       invoiceCount: 2,
//       status: 'in_progress'
//     },
//     {
//       id: 2,
//       poNumber: 'PO-2025-00043',
//       vendorName: 'Apple Distribution',
//       fileName: 'apple_po_april.pdf',
//       uploadedAt: new Date().toISOString(),
//       qty: 60,
//       received: 0,
//       invoiceCount: 0,
//       status: 'pending'
//     }
//   ];

//   constructor(private router: Router) {
//     this.loadPdfjsScript();
//   }

//   // pdfjs script dynamically load karo
//   private loadPdfjsScript(): void {
//     if ((window as any).pdfjsLib) return;
//     const script = document.createElement('script');
//     script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
//     script.onload = () => {
//       (window as any).pdfjsLib.GlobalWorkerOptions.workerSrc =
//         'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
//     };
//     document.head.appendChild(script);
//   }

//   onFileSelect(event: Event) {
//     const input = event.target as HTMLInputElement;
//     const file = input.files?.[0];
//     if (file && file.type === 'application/pdf') {
//       this.uploading = true;
//       this.parsing = true;
//       this.uploadSuccess = false;
//       this.parsePdf(file);
//     }
//     input.value = '';
//   }

//   private parsePdf(file: File): void {
//     const reader = new FileReader();
//     reader.onload = async (e) => {
//       try {
//         const arrayBuffer = e.target?.result as ArrayBuffer;
//         const pdfjs = (window as any).pdfjsLib;

//         const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;

//         let fullText = '';
//         for (let i = 1; i <= pdf.numPages; i++) {
//           const page = await pdf.getPage(i);
//           const content = await page.getTextContent();
//           const pageText = content.items.map((item: any) => item.str).join(' ');
//           fullText += pageText + '\n';
//         }

//         console.log('PDF Text:', fullText); // debug ke liye

//         // Parse fields from text
//         const vendorName = this.extractVendor(fullText);
//         const qty = this.extractQty(fullText);
//         const poNumber = this.extractPoNumber(fullText);

//         const newPO: MockPO = {
//           id: this.purchaseOrders.length + 1,
//           poNumber: poNumber || this.generatePoNumber(),
//           vendorName: vendorName || '—',
//           fileName: file.name,
//           uploadedAt: new Date().toISOString(),
//           qty: qty,
//           received: 0,
//           invoiceCount: 0,
//           status: 'pending'
//         };

//         this.purchaseOrders = [newPO, ...this.purchaseOrders];
//         this.uploading = false;
//         this.parsing = false;
//         this.uploadSuccess = true;
//         setTimeout(() => this.uploadSuccess = false, 3000);

//       } catch (err) {
//         console.error('PDF parse error:', err);
//         this.uploading = false;
//         this.parsing = false;
//       }
//     };
//     reader.readAsArrayBuffer(file);
//   }

//   // Vendor extract — "Vendor" ke baad ka text
//   private extractVendor(text: string): string {
//     // Pattern: "Vendor   Samsung India Pvt Ltd"
//     const patterns = [
//       /Vendor\s*[:\-]?\s*([A-Za-z][\w\s\.&,]+?)(?=\s{2,}|Create Date|PO Number|Status|$)/i,
//       /Vendor Name\s*[:\-]?\s*([A-Za-z][\w\s\.&,]+?)(?=\s{2,}|\n|Create Date|PO|$)/i,
//     ];
//     for (const pattern of patterns) {
//       const match = text.match(pattern);
//       if (match?.[1]?.trim()) return match[1].trim();
//     }
//     return '';
//   }

//   // Total Qty extract
//   private extractQty(text: string): number {
//     const patterns = [
//       /Total Qty\s*[:\-]?\s*(\d+)/i,
//       /Total\s+Qty\s*[:\-]?\s*(\d+)/i,
//       /Qty\s*[:\-]?\s*(\d+)\s*units/i,
//       /Total.*?(\d+)\s*units/i,
//     ];
//     for (const pattern of patterns) {
//       const match = text.match(pattern);
//       if (match?.[1]) return parseInt(match[1]);
//     }
//     return 0;
//   }

//   // PO Number extract
//   private extractPoNumber(text: string): string {
//     const match = text.match(/PO[-\s]?\d{4}[-\s]?\d{4,6}/i);
//     if (match) return match[0].replace(/\s/g, '-').toUpperCase();
//     return '';
//   }

//   private generatePoNumber(): string {
//     const seq = String(Math.floor(Math.random() * 99999) + 1).padStart(5, '0');
//     return `PO-${new Date().getFullYear()}-${seq}`;
//   }

//   viewInvoices(po: MockPO) {
//     this.router.navigate(['/intake/invoices']);
//   }
// }





import { Component } from '@angular/core';
import { DatePipe, TitleCasePipe, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { PdfParserService } from '../../../core/parser.service';

interface MockPO {
  id: number;
  poNumber: string;
  vendorName: string;
  fileName: string;
  uploadedAt: string;
  qty: number;
  received: number;
  invoiceCount: number;
  status: 'pending' | 'in_progress' | 'completed';
}

@Component({
  selector: 'app-po-list',
  standalone: true,
  imports: [DatePipe, TitleCasePipe, NgIf],
  templateUrl: './po-list.component.html',
  styleUrl: './po-list.component.scss'
})
export class PoListComponent {
  uploading = false;
  uploadSuccess = false;

  purchaseOrders: MockPO[] = [
    {
      id: 1,
      poNumber: 'PO-2025-00042',
      vendorName: 'Samsung India Pvt Ltd',
      fileName: 'samsung_po_april.pdf',
      uploadedAt: new Date().toISOString(),
      qty: 120,
      received: 80,
      invoiceCount: 2,
      status: 'in_progress'
    },
    {
      id: 2,
      poNumber: 'PO-2025-00043',
      vendorName: 'Apple Distribution',
      fileName: 'apple_po_april.pdf',
      uploadedAt: new Date().toISOString(),
      qty: 60,
      received: 0,
      invoiceCount: 0,
      status: 'pending'
    }
  ];

  constructor(private router: Router, private pdfParser: PdfParserService) {}

  async onFileSelect(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file || file.type !== 'application/pdf') return;

    this.uploading = true;
    this.uploadSuccess = false;
    input.value = '';

    try {
      // ✅ PdfParserService se parse karo
      const parsed = await this.pdfParser.parsePO(file);
      console.log('Parsed PO:', parsed); // debug

      const newPO: MockPO = {
        id: this.purchaseOrders.length + 1,
        poNumber:     parsed.poNumber   || this.generatePoNumber(),
        vendorName:   parsed.vendorName || '—',
        fileName:     file.name,
        uploadedAt:   parsed.date       || new Date().toISOString(),
        qty:          parsed.totalQty,
        received:     0,
        invoiceCount: 0,
        status:       'pending'
      };

      this.purchaseOrders = [newPO, ...this.purchaseOrders];
      this.uploadSuccess = true;
      setTimeout(() => this.uploadSuccess = false, 3000);

    } catch (err) {
      console.error('PDF parse error:', err);
    } finally {
      this.uploading = false;
    }
  }

  private generatePoNumber(): string {
    const seq = String(Math.floor(Math.random() * 99999) + 1).padStart(5, '0');
    return `PO-${new Date().getFullYear()}-${seq}`;
  }

  viewInvoices(po: MockPO) {
    this.router.navigate(['/intake/invoices']);
  }
}