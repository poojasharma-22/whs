// import { Component } from '@angular/core';
// import { NgIf, NgFor } from '@angular/common';
// import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
// import { ApiService } from '../core/api.service';

// @Component({
//   selector: 'app-layout',
//   standalone: true,
//   imports: [NgIf, NgFor, RouterLink, RouterLinkActive, RouterOutlet],
//   templateUrl: './layout.component.html',
//   styleUrl: './layout.component.scss'
// })
// export class LayoutComponent {
//   notificationCount = 0;

//   constructor(private api: ApiService) {
//     this.api.getNotifications().subscribe(list => {
//       this.notificationCount = list.filter(n => !n.read).length;
//     });
//   }

//   navItems = [
//     { path: '/dashboard', label: 'Dashboard', icon: '📈' },
//     { path: '/intake/invoices', label: 'Product Intake', icon: '📥' },
//     { path: '/stock-allocation', label: 'Stock & Bin Assignment', icon: '📋' },
//     { path: '/store-allocation', label: 'Store Allocation', icon: '🏪' },
//     { path: '/picker', label: 'Picker', icon: '📦' },
//     { path: '/dispatch', label: 'Dispatch', icon: '🚚' },
//     { path: '/tracking', label: 'Tracking & Deviations', icon: '📍' },
//     { path: '/notifications', label: 'Notifications', icon: '🔔' },
//     { path: '/outlet-receiving', label: 'Store Receiving', icon: '✅' },
//     { path: '/reports', label: 'Reports', icon: '📊' },
//     { path: '/masters', label: 'Masters', icon: '⚙️' },
//   ];
// }

import { Component } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { ApiService } from '../core/api.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [NgIf, NgFor, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {
  notificationCount = 0;
  currentUser: { username: string; role: string } | null = null;

  constructor(private api: ApiService, private router: Router) {
    // Notifications load karo
    this.api.getNotifications().subscribe(list => {
      this.notificationCount = list.filter(n => !n.read).length;
    });

    // Logged in user ka naam sidebar mein dikhao
    const stored = localStorage.getItem('user');
    if (stored) {
      try {
        this.currentUser = JSON.parse(stored);
      } catch {
        this.currentUser = null;
      }
    }
  }

  onLogout() {
    // localStorage saaf karo
    localStorage.removeItem('token');
    localStorage.removeItem('user');

    // Login page pe bhej denge 
    this.router.navigate(['/login']);
  }

  navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: '📈' },
    { path: '/purchase-orders', label: 'Purchase Orders', icon: '🧾' },
    { path: '/intake/invoices', label: 'Product Intake', icon: '📥' },
    { path: '/stock-allocation', label: 'Stock & Bin Assignment', icon: '📋' },
    { path: '/store-allocation', label: 'Store Allocation', icon: '🏪' },
    { path: '/picker', label: 'Picker', icon: '📦' },
    { path: '/dispatch', label: 'Dispatch', icon: '🚚' },
    { path: '/tracking', label: 'Tracking & Deviations', icon: '📍' },
    { path: '/notifications', label: 'Notifications', icon: '🔔' },
    { path: '/outlet-receiving', label: 'Store Receiving', icon: '✅' },
    { path: '/reports', label: 'Reports', icon: '📊' },
    { path: '/masters', label: 'Masters', icon: '⚙️' },
  ];
}